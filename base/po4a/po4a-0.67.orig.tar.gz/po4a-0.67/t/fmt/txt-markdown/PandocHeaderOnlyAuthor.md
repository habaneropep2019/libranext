%
% Only author, no title

Other text.
