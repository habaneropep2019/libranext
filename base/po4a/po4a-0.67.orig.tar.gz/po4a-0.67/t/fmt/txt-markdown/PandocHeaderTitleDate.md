% Only title
%
% and date.

Other text.
