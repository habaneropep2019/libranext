Here are three horisontal rules / thematic breaks:
***
---
___
This is a paragraph
+++
which continues
===
and continues
--
**
__
until here

Here are three more rules:
 ***
  ***
   ***
but this is code:

    ***

and this is a paragraph:

Foo
    ***

here are 5 rules:
_____________________________________
 - - -
 **  * ** * ** * **
-     -      -      -
- - - -    
but these are not rules:

_ _ _ _ a

a------

---a---

 *-*

Below is an interrupting rule:

- foo
***
- bar

Below is an interrupting rule:

Foo
***
bar

But this is a header:

Foo
---
bar

This is interrupted by rule:

* Foo
* * *
* Bar

This is a list:

- Foo
- * * *
