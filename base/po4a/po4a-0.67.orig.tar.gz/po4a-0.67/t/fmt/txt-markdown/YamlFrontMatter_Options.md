---
title: "YAML: does it fit in Markdown?"
subtitle: "I mean: why not?"
author: test
numeric_ignored_value: 22
tags:
- yaml
- markdown
people:
  - 
    name: John D'vloper
    title: Developer
    hobbies:
      - Amateur radio
      - Pet adoption & fostering
      - Puzzle
  - 
    name: Tabitha Bitumen
    title: Developer
    hobbies:
      - Ice skating
      - Water polo
      - Caving
paragraph: >
  Some text to translate, please.
---

# YAML: does it fit in Markdown?

Lots of Static Site Generators like Jekyll, Hugo, Lektor and more use
a standard format: Markdown with YAML Front Matter.

Why
---

Because blog posts need metadata!

