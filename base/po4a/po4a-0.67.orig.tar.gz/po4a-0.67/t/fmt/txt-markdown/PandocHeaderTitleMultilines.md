% The document title
  which spans
  multiple lines and is actually so long that it
  will get wrapped by po4a in the output document in order to
  test the wrapping of the output.
% Author
% June 14, 2018

Other text.
