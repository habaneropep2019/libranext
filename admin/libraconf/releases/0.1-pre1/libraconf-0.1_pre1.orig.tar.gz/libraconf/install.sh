#!/bin/bash

# (C) Copyright 2022 Alec Bloss. Licensed under the modified BSD license, also known as the 3-clause BSD license. See the COPYING file for more information.

echo 'Libraconf source installation tool'
echo ''

if [ -z ${DESTDIR+x} ] 
	then 
		echo 'Defaulting to these installation parameters:'
		echo '---------------------------------------------------'
		echo 'Libraconf configuration directory: /conf/libraconf'
		echo 'Libraconf lock directory: 		 /var/lib/libraconf'
		echo 'libconf installation directory:	 /lib'
		echo 'Libranext configuration directory: /conf/libranext'
		echo 'Libraconf installation prefix:	 /usr/sbin'
		echo ''
		DESTDIR='/usr/sbin'
		LIBRACONF_CONFDIR='/conf/libraconf'
		LIBCONF_DESTDIR='/usr/lib'
		LIBRACONF_DESTDIR='/usr/sbin'
		LIBRACONF_LOCKDIR='/var/lib/libraconf'
	else
		echo 'Using these installation parameters:'
		echo '---------------------------------------------------'
		echo 'Libraconf configuration directory: 	/conf/libraconf'
		echo 'Libraconf lock directory: 			/var/lib/libraconf'
		echo 'libconf installation directory:	 	/usr/lib'
		echo 'Libranext configuration directory: 	/conf/libranext'
		echo 'Libraconf installation prefix:	 	/usr/sbin'
		echo "Libraconf installation destination:	$DESTDIR"
		echo ''
		LIBRACONF_CONFDIR="`echo $DESTDIR`/conf/libraconf"
		LIBCONF_DESTDIR="`echo $DESTDIR`/usr/lib"
		LIBRACONF_DESTDIR="`echo $DESTDIR`/usr/sbin"
		LIBRACONF_LOCKDIR="`echo $DESTDIR`/var/lib/libraconf"
fi

if [ ! -d "$DESTDIR" ]
	then
		mkdir -pv "$DESTDIR"
fi

if [ ! -d "$LIBRACONF_CONFDIR" ]
	then
		mkdir -pv "$LIBRACONF_CONFDIR"
fi

if [ ! -d "$LIBCONF_DESTDIR" ]
	then
		mkdir -pv "$LIBCONF_DESTDIR"
fi

if [ ! -d "$LIBRACONF_DESTDIR" ]
	then
		mkdir -pv "$LIBRACONF_DESTDIR"
fi

if [ ! -d "$LIBRACONF_LOCKDIR" ]
	then
		mkdir -pv "$LIBRACONF_LOCKDIR"
fi

cp -aRv src/libraconf "$LIBRACONF_DESTDIR/"
cp -aRv src/libconf "$LIBCONF_DESTDIR/"
cp -aRv src/version "$LIBRACONF_CONFDIR/"

touch "$LIBRACONF_CONFDIR/libconf.location"
touch "$LIBRACONF_LOCKDIR/lock"

chown -v root:root "$LIBRACONF_CONFDIR"
chown -v root:root "$LIBRACONF_CONFDIR/version"
chown -v root:root "$LIBRACONF_DESTDIR"
chown -v root:root "$LIBRACONF_DESTDIR/libraconf"
chown -v root:root "$LIBCONF_DESTDIR/libconf"
chown -v root:root "$LIBRACONF_CONFDIR/libconf.location"
chown -v root:root "$LIBRACONF_LOCKDIR/lock"
chmod -v +x "$LIBRACONF_DESTDIR/libraconf"
chmod -v +x "$LIBCONF_DESTDIR/libconf"

echo ''
echo 'Completed install tasks.'
exit 0