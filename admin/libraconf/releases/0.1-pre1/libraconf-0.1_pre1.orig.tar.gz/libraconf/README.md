# libraconf



## Getting started
Libraconf is the spiritual successor to Libranet's Adminmenu (and XAdminmenu). It aims to be a comprehensive administration and configuration tool to make both the casual user and professional at-ease with all system administration tasks.